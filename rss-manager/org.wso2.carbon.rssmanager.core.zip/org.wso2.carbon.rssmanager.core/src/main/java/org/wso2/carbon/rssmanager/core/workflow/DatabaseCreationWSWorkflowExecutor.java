package org.wso2.carbon.rssmanager.core.workflow;

import org.apache.axiom.om.util.AXIOMUtil;
import org.apache.axis2.AxisFault;
import org.apache.axis2.Constants;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.Options;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.transport.http.HTTPConstants;
import org.apache.axis2.transport.http.HttpTransportProperties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.rssmanager.core.config.WFMessage;
import org.wso2.carbon.rssmanager.core.config.WFMessage;
import org.wso2.carbon.rssmanager.core.dto.restricted.Database;
import org.wso2.carbon.rssmanager.core.dto.restricted.Workflow;
import org.wso2.carbon.rssmanager.core.internal.RSSManagerDataHolder;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.stream.XMLStreamException;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

public class DatabaseCreationWSWorkflowExecutor extends WorkflowExecutor {

	
    private static final Log log = LogFactory.getLog(DatabaseCreationWSWorkflowExecutor.class);

    @XmlRootElement(name = "CreateDBApprovalWorkFlowProcessRequest")
	@XmlAccessorType(XmlAccessType.FIELD)
	static class CreateDBApprovalWorkFlowProcessRequest extends WFMessage {
		
	}
    WorkflowManager wm ;
    
    public DatabaseCreationWSWorkflowExecutor(){
    	 wm = WorkflowManager.getInstance();
    }
    
    @Override
    public String getWorkflowType() {
        return WorkflowConstants.WF_TYPE_SS_DATABASE_CREATION;
    }

    @Override
    public void execute(Workflow workflow) throws WorkflowException {
        if (log.isDebugEnabled()) {
            log.info("Executing Database creation Workflow..");
        }
            workflow.setStatus(WorkflowConstants.WORKFLOW_CREATED);
            buildSOAPMessage(workflow);
            serviceEndpoint = wm.getServiceEndpoint("" + workflow.getTenantId());
            username = wm.getUsername("" + workflow.getTenantId());
            password = wm.getPassword("" + workflow.getTenantId());
            setOptions();
            try {

                client.fireAndForget(AXIOMUtil.stringToOM(payload));

            } catch (AxisFault axisFault) {
                axisFault.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    @Override
    public void complete(Workflow workflow) throws WorkflowException {
    	
    }

    @Override
    public List<Workflow> getWorkflowDetails(String workflowStatus) throws WorkflowException {
        return null;
    }


	@Override
	public void buildSOAPMessage(Workflow wflow) {

		CreateDBApprovalWorkFlowProcessRequest cdbWf = new CreateDBApprovalWorkFlowProcessRequest();
		cdbWf.setEnvironment(wflow.getType());
		cdbWf.setCallbackURL(wflow.getCallbackURL());
		cdbWf.setParameters(wflow.getParameterList());

		JAXBContext context;
		try {
			context = JAXBContext.newInstance(CreateDBApprovalWorkFlowProcessRequest.class);
			Marshaller m = context.createMarshaller();
			m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		    StringWriter w = new StringWriter();
			m.marshal(cdbWf, w);
            payload = w.toString();
            System.out.println(payload);
		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}
   

}


