package org.wso2.carbon.rssmanager.core.config;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import org.wso2.carbon.rssmanager.core.workflow.WorkflowConstants;
import org.wso2.carbon.rssmanager.core.workflow.WorkflowExecutor;

@XmlAccessorType(XmlAccessType.FIELD)
public class WorkflowType {

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_NAME)
	private String name;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_ENABLED)
	private boolean enabled;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_EXECUTOR)
	private String executor;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_ENDPOINT, required = false)
	private String taskServiceEndPoint;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_CALLBACK, required = false)
	private String taskServiceCallbackURL;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_USERNAME, required = false)
	private String taskUsername;

	@XmlElement(name = WorkflowConstants.WORKFLOW_TASK_PASSWORD, required = false)
	private String taskPassword;

	WorkflowExecutor wfExecutor;
	
	public WorkflowExecutor getExecutor() {
		return wfExecutor;
	}
	
	public String getExecutorName() {
		return executor;
	}

	public String getName() {
		return name;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public String getEndpoint() {
		return taskServiceEndPoint;
	}

	public String getCallback() {
		return taskServiceCallbackURL;
	}

	public String getUsername() {
		return taskUsername;
	}

	public String getPassword() {
		return taskPassword;
	}

	public void setEndpoint(String serviceEndpoint) {
		taskServiceEndPoint = serviceEndpoint;
	}

	public void setCallback(String callBackURL) {
		taskServiceCallbackURL = callBackURL;
	}

	public void setUsername(String uname) {
		taskUsername = uname;
	}

	public void setPassword(String pword) {
		taskPassword = pword;
	}
	
	public void loadExecutor() throws ClassNotFoundException, InstantiationException, IllegalAccessException{
		if(executor == null || executor.isEmpty() ){
			executor = "org.wso2.carbon.rssmanager.core.workflow.GenericWFExecutor";
		}
		 Class clazz = WorkflowType.class.getClassLoader().loadClass(executor);
		 wfExecutor = (WorkflowExecutor)clazz.newInstance();
	}

}