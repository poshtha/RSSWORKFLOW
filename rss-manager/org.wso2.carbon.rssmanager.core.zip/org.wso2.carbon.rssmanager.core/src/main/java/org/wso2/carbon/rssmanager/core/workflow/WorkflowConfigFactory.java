package org.wso2.carbon.rssmanager.core.workflow;

import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMNode;
import org.apache.axiom.om.impl.builder.StAXOMBuilder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.wso2.carbon.context.CarbonContext;
import org.wso2.carbon.registry.core.Registry;
import org.wso2.carbon.registry.core.Resource;
import org.wso2.carbon.registry.core.exceptions.RegistryException;
import org.wso2.carbon.rssmanager.common.RSSManagerConstants;
import org.wso2.carbon.rssmanager.core.config.RSSConfig;
import org.wso2.carbon.rssmanager.core.config.WFMessage;
import org.wso2.carbon.rssmanager.core.config.WorkflowExecutorConfig;
import org.wso2.carbon.rssmanager.core.config.WorkflowType;
import org.wso2.carbon.rssmanager.core.config.WFMessage.Parameter;
import org.wso2.carbon.rssmanager.core.dto.restricted.Workflow;
import org.wso2.carbon.rssmanager.core.internal.RSSManagerDataHolder;
import org.wso2.carbon.rssmanager.core.util.RSSManagerUtil;
import org.wso2.carbon.utils.CarbonUtils;
import org.wso2.securevault.SecretResolver;
import org.wso2.securevault.SecretResolverFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import java.io.File;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WorkflowConfigFactory implements Serializable {

	private static final Log log = LogFactory.getLog(WorkflowConfigFactory.class);

	private static final QName PROP_Q = new QName("Property");

	private static final QName ATT_NAME = new QName("name");

	private Map<String, WorkflowExecutor> workflowExecutorMap = new HashMap(); ;

	private static WorkflowConfigFactory thisInstance = new WorkflowConfigFactory();

	public WorkflowConfigFactory() {
		
	}

	public WorkflowExecutor getWorkflowExecutor(String workflowExecutorType) {
		return workflowExecutorMap.get(workflowExecutorType);
	}

	public static WorkflowConfigFactory getInstance() {
		return thisInstance;
	}
	
	public void addWorkflow(Workflow wfDTO){
		
	}

	public void load(CarbonContext carbonContext) {

		int tid = carbonContext.getTenantId();
		String uname = carbonContext.getUsername();
		try {
			Registry registry = RSSManagerDataHolder.getInstance().getRegistry(uname, tid);
			Resource resource = registry.get(WorkflowConstants.WORKFLOW_CONFIG);

			InputStream in = resource.getContentStream();

			JAXBContext context = JAXBContext.newInstance(WorkflowExecutorConfig.class);
			Unmarshaller um = context.createUnmarshaller();
			WorkflowExecutorConfig wfConfig = (WorkflowExecutorConfig) um.unmarshal(in);
			List<WorkflowType> wfTasks = wfConfig.getTasks();
			for (WorkflowType task : wfTasks) {
				if (task.getEndpoint() == null) {
					task.setEndpoint(wfConfig.getServiceEndpoint());
				}
				if (task.getCallback() == null) {
					task.setCallback(wfConfig.getCallbackURL());
				}
				if (task.getUsername() == null) {
					task.setUsername(wfConfig.getGlobalUsername());
				}
				if (task.getPassword() == null) {
					task.setPassword(wfConfig.getGlobalPassword());
				}
				task.loadExecutor();
				task.getExecutor().setWFTask(task.getName());
			}
			wfConfig.setTasks(wfTasks);

			RSSManagerDataHolder.getInstance().addWorkFlowConfig(Integer.toString(tid), wfConfig);

		} catch (RegistryException e) {
			log.error("Error accessing tenant registry");
		} catch (JAXBException e) {
			log.error("Error accessing reading configuration");
		} catch (ClassNotFoundException e) {
			log.error("Error loading executor");
        } catch (InstantiationException e) {
			log.error("Error loading executor");
        } catch (IllegalAccessException e) {
			log.error("Error loading executor");
        }
	}


	private void loadProperties(OMElement executorElem, Object workflowClass)
	                                                                         throws WorkflowException {

		for (Iterator it = executorElem.getChildrenWithName(PROP_Q); it.hasNext();) {
			OMElement propertyElem = (OMElement) it.next();
			String propName = propertyElem.getAttribute(ATT_NAME).getAttributeValue();
			if (propName == null) {
				handleException("An Executor class property must specify the name attribute");
			} else {
				OMNode omElt = propertyElem.getFirstElement();
				if (omElt != null) {
					setInstanceProperty(propName, omElt, workflowClass);
				} else if (propertyElem.getText() != null) {
					String value = propertyElem.getText();
					setInstanceProperty(propName, value, workflowClass);
				} else {

					handleException("An Executor class property must specify "
					                + "name and text value, or a name and a child XML fragment");
				}
			}
		}
	}

	public void setInstanceProperty(String name, Object val, Object obj) throws WorkflowException {

		String mName = "set" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
		Method method;

		try {
			Method[] methods = obj.getClass().getMethods();
			boolean invoked = false;

			for (Method method1 : methods) {
				if (mName.equals(method1.getName())) {
					Class[] params = method1.getParameterTypes();
					if (params.length != 1) {
						handleException("Did not find a setter method named : " +
						                mName +
						                "() that takes a single String, int, long, float, double ," +
						                "OMElement or boolean parameter");
					} else if (val instanceof String) {
						String value = (String) val;
						if (String.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, String.class);
							method.invoke(obj, new String[] { value });
						} else if (int.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, int.class);
							method.invoke(obj, new Integer[] { new Integer(value) });
						} else if (long.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, long.class);
							method.invoke(obj, new Long[] { new Long(value) });
						} else if (float.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, float.class);
							method.invoke(obj, new Float[] { new Float(value) });
						} else if (double.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, double.class);
							method.invoke(obj, new Double[] { new Double(value) });
						} else if (boolean.class.equals(params[0])) {
							method = obj.getClass().getMethod(mName, boolean.class);
							method.invoke(obj, new Boolean[] { Boolean.valueOf(value) });
						} else {
							continue;
						}
					} else if (val instanceof OMElement && OMElement.class.equals(params[0])) {
						method = obj.getClass().getMethod(mName, OMElement.class);
						method.invoke(obj, new OMElement[] { (OMElement) val });
					} else {
						continue;
					}
					invoked = true;
					break;
				}
			}

			if (!invoked) {
				handleException("Did not find a setter method named : " + mName +
				                "() that takes a single String, int, long, float, double " +
				                "or boolean parameter");
			}

		} catch (Exception e) {
			handleException("Error invoking setter method named : " + mName +
			                "() that takes a single String, int, long, float, double " +
			                "or boolean parameter", e);
		}
	}

	private static void handleException(String msg) throws WorkflowException {
		log.error(msg);
		throw new WorkflowException(msg);
	}

	private static void handleException(String msg, Exception e) throws WorkflowException {
		log.error(msg, e);
		throw new WorkflowException(msg, e);
	}
	
	
	public static void main(String args[]){
		
		DatabaseCreationWSWorkflowExecutor db = new DatabaseCreationWSWorkflowExecutor();
		Workflow w = new Workflow();
		w.setCallbackURL("http://");
		w.setTenantId(2134321);
		w.setType("RSS");
		w.addParameter("user", "bob");
		db.buildSOAPMessage(w);
	}
}
