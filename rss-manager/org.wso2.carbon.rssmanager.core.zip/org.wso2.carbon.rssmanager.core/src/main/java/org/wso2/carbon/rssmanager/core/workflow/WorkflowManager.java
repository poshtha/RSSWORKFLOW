package org.wso2.carbon.rssmanager.core.workflow;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.wso2.carbon.registry.core.Registry;
import org.wso2.carbon.registry.core.Resource;
import org.wso2.carbon.registry.core.exceptions.RegistryException;
import org.wso2.carbon.registry.core.utils.UUIDGenerator;
import org.apache.axiom.om.util.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.context.CarbonContext;
import org.wso2.carbon.context.PrivilegedCarbonContext;
import org.wso2.carbon.rssmanager.core.config.WFMessage;
import org.wso2.carbon.rssmanager.core.config.WorkflowExecutorConfig;
import org.wso2.carbon.rssmanager.core.config.WorkflowType;
import org.wso2.carbon.rssmanager.core.dto.restricted.Workflow;
import org.wso2.carbon.rssmanager.core.internal.RSSManagerDataHolder;
import org.wso2.carbon.rssmanager.core.util.RSSManagerUtil;

import javax.cache.Cache;
import javax.cache.Caching;
import javax.sql.DataSource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class WorkflowManager {

	private static final Log log = LogFactory.getLog(WorkflowManager.class);

	private static WorkflowManager instance;

	private static DataSource dataSource;

	private WorkflowConfigFactory config;

	private WorkflowManager() {
	}

	public static WorkflowManager getInstance() {
		if (instance == null) {
			dataSource = RSSManagerUtil.getDataSource();
			instance = new WorkflowManager();
		}
		return instance;
	}
	
    public String generateWFID(){
        String UUID = UUIDGenerator.generateUUID();
        return UUID;
    }
	
	public String persistResource(Serializable object) {
		String encoded = null;
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
			objectOutputStream.writeObject(object);
			objectOutputStream.close();
			encoded = new String(Base64.encode(byteArrayOutputStream.toByteArray()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return encoded;
	} 
	
	public Object parseResource(String string) {
		byte[] bytes = Base64.decode(string);
		Object object = null;
		try {
			ObjectInputStream objectInputStream =
			                                      new ObjectInputStream(
			                                                            new ByteArrayInputStream(
			                                                                                     bytes));
			object = objectInputStream.readObject();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return object;
	}	
			
	public void load(CarbonContext carbonContext) {

		int tid = carbonContext.getTenantId();
		String uname = carbonContext.getUsername();
		try {
			Registry registry = RSSManagerDataHolder.getInstance().getRegistry(uname, tid);
			Resource resource = registry.get(WorkflowConstants.WORKFLOW_CONFIG);

			InputStream in = resource.getContentStream();

			JAXBContext context = JAXBContext.newInstance(WorkflowExecutorConfig.class);
			Unmarshaller um = context.createUnmarshaller();
			WorkflowExecutorConfig wfConfig = (WorkflowExecutorConfig) um.unmarshal(in);
			List<WorkflowType> wfTasks = wfConfig.getTasks();
			for (WorkflowType task : wfTasks) {
				if (task.getEndpoint() == null) {
					task.setEndpoint(wfConfig.getServiceEndpoint());
				}
				if (task.getCallback() == null) {
					task.setCallback(wfConfig.getCallbackURL());
				}
				if (task.getUsername() == null) {
					task.setUsername(wfConfig.getGlobalUsername());
				}
				if (task.getPassword() == null) {
					task.setPassword(wfConfig.getGlobalPassword());
				}
				task.loadExecutor();
				task.getExecutor().setWFTask(task.getName());
			}

			RSSManagerDataHolder.getInstance().addWorkFlowConfig(Integer.toString(tid), wfConfig);

		} catch (RegistryException e) {
			log.error("Error accessing tenant registry");
		} catch (JAXBException e) {
			log.error("Error accessing reading configuration");
		} catch (ClassNotFoundException e) {
			log.error("Error loading executor");
		} catch (InstantiationException e) {
			log.error("Error loading executor");
		} catch (IllegalAccessException e) {
			log.error("Error loading executor");
		}
	}

	public boolean isTenentWFEnabled(String tid) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getGlobalEnabled();
	}

	public boolean isTaskWFEnabled(String tid, String task) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getWFEnabled(task);
	}
	
	public String getServiceEndpoint(String tid) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getServiceEndpoint();
	}

	public String getCallbackURL(String tid) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getCallbackURL();
	}

	public String getUsername(String tid) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getGlobalUsername();
	}
	
	public String getPassword(String tid) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getGlobalPassword();
	}
	
	private static void handleException(String msg) throws WorkflowException {
		log.error(msg);
		throw new WorkflowException(msg);
	}

	public WorkflowExecutor getWorkflowExecutor(String tid, String task) {
		return RSSManagerDataHolder.getInstance().getWorkFlowConfig(tid).getWFExecutor(task);
	}

	public void updateWFStatus(String wfId, String status) {

		Connection conn;
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);

			String updateWFStatusQuery = "UPDATE RM_WORKFLOW SET STATUS=? WHERE WFID = ?";
			PreparedStatement addWFStatement = conn.prepareStatement(updateWFStatusQuery);
			addWFStatement.setString(1, status);
			addWFStatement.setString(2, wfId);
			addWFStatement.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getWFStatus(String wfId) {

		Connection conn;
		String status = "";
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);

			String updateWFStatusQuery = "SELECT STATUS FROM RM_WORKFLOW WHERE WFID = ?";
			PreparedStatement addWFStatement = conn.prepareStatement(updateWFStatusQuery);
			addWFStatement.setString(1, wfId);
			addWFStatement.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}

	public String getWFID(String taskType, String resouces, String task) {
		Connection conn;
		String wfId = "";
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);

			String updateWFStatusQuery =
			                             "SELECT WFID FROM RM_WORKFLOW WHERE TASK_TYPE = ? OR RESOURCES = ? OR TASK = ?";
			PreparedStatement addWFStatement = conn.prepareStatement(updateWFStatusQuery);
			addWFStatement.setString(1, taskType);
			addWFStatement.setString(2, resouces);
			addWFStatement.setString(3, task);
			addWFStatement.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return wfId;
	}

	public void createWorkflow(Workflow wfInfo) {
		Connection conn;
		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			String createDBQuery =
			                       "INSERT INTO RM_WORKFLOW(WFID, TYPE , TENANT_ID, TENANT_DOMAIN, CREATE_TIME, UPDATE_TIME, STATUS) VALUES (?,?,?,?,?,?,?)";
			PreparedStatement addWFStatement = conn.prepareStatement(createDBQuery);
			addWFStatement.setString(1, "" + wfInfo.getId());
			addWFStatement.setString(2, wfInfo.getType());
			addWFStatement.setInt(3, wfInfo.getTenantId());
			addWFStatement.setString(4, wfInfo.getTenantDomain());
			addWFStatement.setLong(5, wfInfo.getCreateTime());
			addWFStatement.setLong(6, wfInfo.getUpdateTime());
			addWFStatement.setString(7, wfInfo.getStatus());

			addWFStatement.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}