package org.wso2.carbon.rssmanager.core.workflow;

/**
 * Created by msffayaza on 10/18/14.
 */
public class WorkflowConstants {

	public static final String WF_TYPE_SS_DATABASE_CREATION = "SS_DATABASE_CREATION";

	public static final String SS = "SS";

	public static final String WORKFLOW_CONFIG = "workflowconfig";

	public static final String WORKFLOW_ENDPOINT = "serviceendpoint";

	public static final String WORKFLOW_CALLBACK = "callbackurl";

	public static final String WORKFLOW_GLOBAL_USER = "username";

	public static final String WORKFLOW_GLOBAL_PASSWORD = "password";

	public static final String WORKFLOW_GLOBAL_ENABLED = "enabled";

	public static final String WORKFLOW_TASK = "task";

	public static final String WORKFLOW_TASKS = "tasks";

	public static final String WORKFLOW_TASK_NAME = "name";

	public static final String WORKFLOW_TASK_ENABLED = "enabled";

	public static final String WORKFLOW_TASK_EXECUTOR = "executor";

	public static final String WORKFLOW_TASK_ENDPOINT = "endpoint";

	public static final String WORKFLOW_TASK_CALLBACK = "callback";

	public static final String WORKFLOW_TASK_USERNAME = "username";

	public static final String WORKFLOW_TASK_PASSWORD = "password";

	public static final String PASSWORD = "Password";

	public static final String PASSWORD_ = "password";

	public static final String DATABASE_CREATION = "DatabaseCreation";

	public static final String WORKFLOW_CREATED = "CREATED";

	public static final String WORKFLOW_APPROVED = "APPROVED";

	public static final String WORKFLOW_REJECT = "REJECT";
	
	public static final String WORKFLOW_MES_DESC = "description";
	
	public static final String WORKFLOW_MES_WFID = "workflowID";

	public static final String WORKFLOW_MES_WFREF = "workflowExtReference";
	
	public static final String WORKFLOW_MES_ENV = "wor:environment";

	public static final String WORKFLOW_MES_CALL = "callBackURL";


	

}
