package org.wso2.carbon.rssmanager.core.workflow;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.rssmanager.core.config.RSSManagementRepository;
import org.wso2.carbon.rssmanager.core.dao.RSSDAOFactory;
import org.wso2.carbon.rssmanager.core.dao.exception.RSSDAOException;
import org.wso2.carbon.rssmanager.core.dao.impl.DatabaseDAOImpl;
import org.wso2.carbon.rssmanager.core.dto.restricted.Database;
import org.wso2.carbon.rssmanager.core.dto.restricted.Workflow;
import org.wso2.carbon.rssmanager.core.environment.dao.EnvironmentManagementDAOFactory;
import org.wso2.carbon.rssmanager.core.internal.RSSManagerDataHolder;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.List;
import java.util.Set;



public class DatabseCreationSimpleWorkflowExecutor  extends WorkflowExecutor {

    private static final Log log =
            LogFactory.getLog(DatabseCreationSimpleWorkflowExecutor.class);

    @Override
    public String getWorkflowType() {
        return WorkflowConstants.WF_TYPE_SS_DATABASE_CREATION;
    }

    @Override
    public void execute(Workflow workflow) throws WorkflowException {
        if (log.isDebugEnabled()) {
            log.info("Executing Application creation Workflow..");
        }
            workflow.setStatus("APPROVED");
            workflow.setDescribtion("NO NEED PRIVILEGE USER APPROVAL");

     complete(workflow);

    }

    @Override
    public void complete(Workflow workflow) throws WorkflowException {
        super.complete(workflow);
    }

    @Override
    public List<Workflow> getWorkflowDetails(String workflowStatus) throws WorkflowException {
        return null;
    }

	@Override
    public void buildSOAPMessage(Workflow wflow) {
	    // TODO Auto-generated method stub
	    
    }
}
